$(document).ready(function() {
	var navTrigger	=	$('.nav-trigger'),
	navPanel	=	$('.off-canvas'),
	mainContent	=	$('.canvas');

	$(navTrigger).click(function(e) {
		e.preventDefault();
		$('body').toggleClass('reveal-nav');
		$(navPanel).toggleClass('show');
		$(this).toggleClass('clicked');
	});

	$(window).bind('scroll', function () {
		if ($(window).scrollTop() > 140) {
			$('.page-nav').addClass('fixed');
			$('body').addClass('fixednav')
		} else {
			$('.page-nav').removeClass('fixed');
			$('body').removeClass('fixednav')
		}
	});

	$(window).on("scroll", function () {
		var scroll = $(window).scrollTop();
		if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
			$(".parallax").css('-webkit-transform', 'translate3d(0,' +  (scroll/4)  + 'px, 0)');
		}else {
			var scroll = $(window).scrollTop();
			$(".parallax").css('transform', 'translate3d(0,' +  (scroll/4)  + 'px, 0)');
		}
	})

	$('.video-play').click(function(e) {
		e.preventDefault();
		$(this).parents('.video-intro').find('.video-wrap').fadeIn();
		$(this).parents('.video-intro').addClass('video-playing')
		$(this).parents('.video-intro').find('.video-wrap #vid').html('<iframe width="600" height="338" id="ytvideo" frameborder="0" allowfullscreen src="http://www.youtube.com/embed/'+$(this).attr("data-vidid")+'?rel=0&amp;controls=0&amp;showinfo=0&amp;autoplay=1"></iframe>').show();
	});

	$('.close-btn').click(function(e) {
		e.preventDefault();
		$(this).parents('.video-intro').find('.video-wrap').fadeOut();
		$(this).parents('.video-intro').removeClass('video-playing')
		$(this).parents('.video-intro').find('.video-wrap #vid').html('').hide();
	});


});
